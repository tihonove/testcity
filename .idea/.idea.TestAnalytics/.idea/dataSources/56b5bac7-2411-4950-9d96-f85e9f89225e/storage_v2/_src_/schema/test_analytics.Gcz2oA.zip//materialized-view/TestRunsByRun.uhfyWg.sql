CREATE MATERIALIZED VIEW test_analytics.TestRunsByRun
            (
             `JobId` String,
             `JobRunId` String,
             `BranchName` String,
             `TestId` String,
             `State` Enum8('Success' = 1, 'Failed' = 2, 'Skipped' = 3),
             `Duration` Decimal(18, 0),
             `StartDateTime` DateTime,
             `AgentName` String,
             `AgentOSName` String
                )
            ENGINE = MergeTree
                PARTITION BY toMonday(StartDateTime)
                ORDER BY (JobId, JobRunId, TestId)
                TTL StartDateTime + toIntervalYear(1)
                SETTINGS index_granularity = 8192
AS
SELECT JobId,
       JobRunId,
       BranchName,
       TestId,
       State,
       Duration,
       StartDateTime,
       AgentName,
       AgentOSName
FROM test_analytics.TestRuns;

