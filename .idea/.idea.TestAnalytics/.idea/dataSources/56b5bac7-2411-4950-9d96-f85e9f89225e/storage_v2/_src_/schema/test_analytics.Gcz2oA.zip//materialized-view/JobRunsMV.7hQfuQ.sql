CREATE MATERIALIZED VIEW test_analytics.JobRunsMV
            (
             `JobId` String,
             `JobRunId` String,
             `BranchName` String,
             `AgentName` String,
             `AgentOSName` String,
             `StartDateTime` DateTime,
             `EndDateTime` DateTime
                )
            ENGINE = MergeTree
                PARTITION BY toMonday(StartDateTime)
                ORDER BY JobId
                TTL StartDateTime + toIntervalYear(1)
                SETTINGS index_granularity = 8192
AS
SELECT JobId,
       JobRunId,
       first_value(TestRuns.BranchName)  AS BranchName,
       first_value(TestRuns.AgentName)   AS AgentName,
       first_value(TestRuns.AgentOSName) AS AgentOSName,
       min(TestRuns.StartDateTime)       AS StartDateTime,
       max(TestRuns.StartDateTime)       AS EndDateTime
FROM test_analytics.TestRuns
GROUP BY JobId,
         JobRunId;

